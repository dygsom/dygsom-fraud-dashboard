/**
 * useAuth Hook
 *
 * Re-export the useAuth hook from AuthContext for convenience
 */

export { useAuth } from '@/context/AuthContext';
